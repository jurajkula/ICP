Názov: ProjektICP
Autori: Juraj Kula (xkulaj02), Michal Vaško (xvasko14)
Popis: Program pre vytváranie a editáciu blokových schémat

Ovládanie:
-Dvojklik na plátno ľavým tlačítkom - vytváranie blokov
-Dvojklik na blok ľavým tlačítkom - editácia blokov
-Dvojklik na port pravým tlačítkom - zrušenie spojenia
-Dvojklik na blok pravým tlačítkom - zmazanie bloku
