Názov: ProjektICP
Autori: Juraj Kula (xkulaj02), Michal Vaško (xvasko14)
Popis: Program pre vytváranie a editáciu blokových schémat